package com.training.webservice;

import java.net.MalformedURLException;
import java.rmi.RemoteException;

public class MainApp {

	public static void main(String[] args) throws MalformedURLException, RemoteException {
		// TODO Auto-generated method stub
		
		java.net.URL url = new java.net.URL("http://localhost:8080//Webservice//services//CallService");
		org.apache.axis.client.Service service = new org.apache.axis.client.Service();
		
		CallServiceSoapBindingStub stub = new CallServiceSoapBindingStub(url,service);
		
		int result = stub.add(35, 15);
		int subResult = stub.sub(10, 20);
		
		System.out.println("Addition result :"+result);
		System.out.println("Sub result :"+subResult);

	}

}
