package com.java.core.superKeyword;

  /**
   * 
   * @author Yoga
   *
   *	1. Super keyword in java is a reference variable, which is referred to 
   *		immediate parent class object
   *
   *	2. When you create a instance of subclass, an instance of parent is created implicitly
   *		and which is referred by super reference variable.
   */

class animal
{
	String color = "white";
	
	animal()
	{
		//color = "red";
		System.out.println("super class constructor");
	}
	//color = "red";
	void msg()
	{
		System.out.println("parent-class method");
	}
	{
		System.out.println("instance intializer");
	}
	{
		color="red";
		System.out.println("main method instance block");
	}
	
}

class dog extends animal
{
	String color = "black";
	
	dog(){
		super();// 3. which is used to call super class constructor , either this() or super() should be the first line in constructor.
		System.out.println("subclass constructor");
	}
	
	void print()
	{
		super.msg();// 2. stmt can be used to call super class method
		System.out.println(color);
		System.out.println(super.color);// 1. which is used to call the super class instance variable using super keyword
		
	}
	
}

public class SuperParentClassInstance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		dog d = new dog();
		d.print();

	}
	{
		System.out.println("main method instance block");
	}

}
