package com.java.core.practice;

interface AA
{
	 class B
	{
		void show() {
			System.out.println("inside interface");
		}
	}
}

public class InterfaceInsideClass extends AA.B{
	
	/*@Override
	public void show() {
		// TODO Auto-generated method stub
		System.out.println("interface-method");
		
	}*/

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AA.B b = new InterfaceInsideClass();
		b.show();

	}

	

}
