package com.java.core.practice;

class Apple
{
    int i = 10;
    void msg()
    {
    	System.out.println("parent-class");
    }
}
 
class Box extends Apple
{
    int j = 20;
    int i = 20;
    
    void dis()
    {
    	System.out.println("child-class");
    //	System.out.println(i);
    }
}
 
class Cat extends Box
{
    int k = 30;
}

public class ClassCasteException {

	public static void main(String[] args) throws InstantiationException, IllegalAccessException {
		// TODO Auto-generated method stub
		
		Apple a = new Box();
		
		System.out.println(a.i);
		a.msg();
		
		Box b = (Box) a;
		
		System.out.println(b.i);
		b.msg();
		b.dis();
		
		
		
	//	Cat c = (Cat) b;
		
		Box c = new Cat();
		c.msg();
		
		Cat cc = (Cat) c;
		
		cc.dis();
		
		Cat c3 = new Cat();
	//	c3.i;
		
		Apple aa = Apple.class.newInstance();
		
		Constructor<Apple> cc = Apple.class.getConstructors();
		
		
		

	}

}
