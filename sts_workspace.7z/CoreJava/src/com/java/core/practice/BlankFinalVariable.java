package com.java.core.practice;

public class BlankFinalVariable {
	
	final int i=0;
	
	i = 20;
	
	BlankFinalVariable()
	{
		i = 10;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		BlankFinalVariable bfv = new BlankFinalVariable();
		System.out.println(bfv.i);
	}

}
