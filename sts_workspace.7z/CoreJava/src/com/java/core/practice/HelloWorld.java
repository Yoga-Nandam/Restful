package com.java.core.practice;

public class HelloWorld {
	
	static {
		
		System.out.println("static-block");
	}

	/*public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Hello Kavita!!!");

	}*/

}
