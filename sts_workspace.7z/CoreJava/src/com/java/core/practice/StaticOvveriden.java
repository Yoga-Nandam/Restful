package com.java.core.practice;

class AB{
	
	static void show()
	{
		System.out.println("show-A");
	}
	void msg()
	{
		System.out.println("msg-A");
	}
}

class BC extends AB{
	
	static void show()
	{
		System.out.println("show-B");
	}
	void msg()
	{
		System.out.println("msg-B");
	}
}

public class StaticOvveriden {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AB ab = new BC();
		
		ab.show();
		ab.msg();

	}

}
