package com.java.core.practice;

abstract class hello
{
	abstract void show();
	public void msg(){
		
	}
}

public class abstracttTEST extends hello{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		abstracttTEST abt = new abstracttTEST();
		abt.msg();
	abt.show();


	}

	@Override
	void show() {
		// TODO Auto-generated method stub
		
		System.out.println("Abstract method");
		
	}
	
	public void msg()
	{
		System.out.println("concrete class");
	}
	
	
}
