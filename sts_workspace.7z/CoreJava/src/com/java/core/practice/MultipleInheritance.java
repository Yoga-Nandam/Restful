package com.java.core.practice;

interface A{
	 void show();
}
interface B{
	void show();
}

public class MultipleInheritance implements A,B {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public void show() {
		// TODO Auto-generated method stub
		
	}

}
