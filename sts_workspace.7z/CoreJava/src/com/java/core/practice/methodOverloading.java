package com.java.core.practice;

public class methodOverloading {
	
	void methodOVerload(int i) {
		
	}
	int methodOverload(int i) {
		return i;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		

	}

}
