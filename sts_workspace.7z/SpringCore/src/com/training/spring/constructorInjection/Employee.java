package com.training.spring.constructorInjection;
import java.util.List;

import com.training.spring.constructorInjection.Address;

public class Employee {
	
	private int age;
	private String name;
	private List<Address> address;
	
	Employee(int age,String name,List<Address> address)
	{
		this.age = age;
		this.name = name;
		this.address =address;
	}

	public int getAge() {
		return age;
	}

	public String getName() {
		return name;
	}

	public List<Address> getAddress() {
		return address;
	}
	
	

}
