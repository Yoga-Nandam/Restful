package com.training.spring.constructorInjection;

import java.util.Iterator;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext app = new ClassPathXmlApplicationContext("BeanCI.xml");
		
		Employee emp = (Employee)app.getBean("emp");
		
		//emp.toString();
		
		System.out.println(emp.getAge());
		System.out.println(emp.getName());
		/*Iterator<Address> itr = emp.getAddress().iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next().getStreet());
			System.out.println(itr.next().getCity());
		//	System.out.println(itr.next().getState());
		}*/
		
		for(Address add : emp.getAddress())
		{
			System.out.println(add.getStreet());
			System.out.println(add.getCity());
			System.out.println(add.getState());
		}
		
		//System.out.println("welcome");

	}

}
