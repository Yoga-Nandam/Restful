package com.training.spring.autowire_constructor;

public class Person {
	private String personName;
	private Car car;
	
	public Person(Car car)
	{
		this.car = car;
	}
	
	
	
	public String getPersonName() {
		return personName;
	}

	public void setPersonName(String personName) {
		this.personName = personName;
	}




	public Car getCar() {
		return car;
	}
	/*public void setCar(Car car) {
		this.car = car;
	}*/
	
}
