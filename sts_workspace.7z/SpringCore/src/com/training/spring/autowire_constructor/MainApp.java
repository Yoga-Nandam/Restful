package com.training.spring.autowire_constructor;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BeanFactory beanFactory = new ClassPathXmlApplicationContext("Bean.xml");
	      Person obj = (Person) beanFactory.getBean("personBean");
	      
	      System.out.println(obj.getCar().getCarType().toString());
	      System.out.println(obj.getCar().getCarName().toString());
	      System.out.println(obj.getPersonName());

	}

}
