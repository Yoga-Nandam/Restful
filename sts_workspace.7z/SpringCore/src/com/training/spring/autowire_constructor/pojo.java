package com.training.spring.autowire_constructor;

public class pojo {

}
