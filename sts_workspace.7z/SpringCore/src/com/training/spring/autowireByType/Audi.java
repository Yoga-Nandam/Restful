package com.training.spring.autowireByType;

public class Audi extends Car{

}
