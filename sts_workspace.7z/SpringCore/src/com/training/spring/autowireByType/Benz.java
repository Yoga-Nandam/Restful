package com.training.spring.autowireByType;

public class Benz extends Car{

}
