package com.training.spring.placeholder.annotation;

public class Person {

}
