package com.training.springcore.scopeBean;

import java.util.Date;

import org.springframework.beans.factory.annotation.Required;

public class Employee {
	
	private int age;
	private String firstName;
	private Date date;
	
	
	
	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public void setAge(int age) {
		this.age = age;
	}
	@Required
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public int getAge() {
		return age;
	}

	public String getFirstName() {
		return firstName;
	}

	
	
}
