package com.training.springcore.scopeBean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.springcore.scopeBean.*;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
ApplicationContext app = new ClassPathXmlApplicationContext(new String[] {"BeanCI.xml","Bean.xml"});
		
		Employee emp = (Employee)app.getBean("empScope");
		
		emp.setAge(18);
		System.out.println(emp.getAge());
		
		Employee emp2 = (Employee)app.getBean("empScope");
		
		System.out.println(emp2.getAge());
		System.out.println(emp2.getDate());
		System.out.println(emp2.getFirstName());

	}

}
