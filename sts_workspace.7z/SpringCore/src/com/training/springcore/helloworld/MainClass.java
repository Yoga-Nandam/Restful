package com.training.springcore.helloworld;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.expression.spel.SpelParserConfiguration;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BeanFactory beanFactory = new ClassPathXmlApplicationContext("Bean.xml");
	      HelloWorld obj = (HelloWorld) beanFactory.getBean("welcome");
	      obj.getMessage();
		
		System.out.println(obj.getMessage().toString());

	}

}
