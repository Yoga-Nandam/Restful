package com.training.controller;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class EmpController {
	
	@RequestMapping("/")
	public String msg()
	{
		return "Hello Yoga!!";
	}
	
	@RequestMapping("/welcome")
	public ModelAndView welcome(Model m)
	{
		m.addAttribute("message", "Welcome to spring Boot app");
		return new ModelAndView("HomePage");
	}
	
	@RequestMapping("/login")
	public ModelAndView login(Model m)
	{
		//m.addAttribute("message", "Welcome to spring Boot app");
		return new ModelAndView("login");
	}
	
	@RequestMapping("/registrationPage")
	public ModelAndView Registration(Model m)
	{
		//m.addAttribute("message", "Welcome to spring Boot app");
		return new ModelAndView("Registration");
	}
	
	
}
