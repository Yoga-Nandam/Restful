package com.example.UserSummary.model;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;

public class createUserRequestModel {
	private String fname;
	private String lname;
	@NotNull(message="Email cannot be null")
	@Email
	private String email;
	private String password;
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
