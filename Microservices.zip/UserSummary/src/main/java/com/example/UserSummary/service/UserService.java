package com.example.UserSummary.service;

import org.springframework.stereotype.Service;

import com.example.UserSummary.model.UserDTO;
@Service
public interface UserService {
	UserDTO createUser(UserDTO user);

}
