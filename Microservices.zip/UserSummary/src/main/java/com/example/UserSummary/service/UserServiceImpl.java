package com.example.UserSummary.service;

import java.util.UUID;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.UserSummary.model.UserDTO;
import com.example.UserSummary.model.UserEntity;
import com.example.UserSummary.repo.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	UserRepository userRepo;

	@Autowired
	public UserServiceImpl(UserRepository userRepo) {
		this.userRepo = userRepo;
	}

	@Override
	public UserDTO createUser(UserDTO user) {
		// TODO Auto-generated method stub
		user.setUserId(UUID.randomUUID().toString());
		ModelMapper mm = new ModelMapper();
		mm.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		UserEntity userEntity = mm.map(user, UserEntity.class);
		userEntity.setEncryptedPwd("test");
		userRepo.save(userEntity);
		UserDTO userDTO = mm.map(userEntity, UserDTO.class);
		return userDTO;
	}

}
