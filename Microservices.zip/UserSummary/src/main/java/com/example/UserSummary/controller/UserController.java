package com.example.UserSummary.controller;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.UserSummary.model.UserDTO;
import com.example.UserSummary.model.createUserRequestModel;
import com.example.UserSummary.model.createUserResponseModel;
import com.example.UserSummary.service.UserService;

@RestController
@RequestMapping("/User")
public class UserController {
	@Autowired
	public Environment env;
	@Autowired
	UserService userservice;

	@GetMapping
	public String getUser() {
		return "User Summary Details, port number is :" + env.getProperty("local.server.port");
	}

	@PostMapping(path = "/UserBody", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)

	public ResponseEntity<createUserResponseModel> getRequestBody(@RequestBody createUserRequestModel ud) {
		ModelMapper mm = new ModelMapper();
		mm.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		UserDTO userDTO = mm.map(ud, UserDTO.class);
		userservice.createUser(userDTO);
		createUserResponseModel returnValue = mm.map(userDTO, createUserResponseModel.class);
		return  ResponseEntity.status(HttpStatus.CREATED).body(returnValue);
	}

}
