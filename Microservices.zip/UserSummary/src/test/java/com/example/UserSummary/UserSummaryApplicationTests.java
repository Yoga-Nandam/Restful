package com.example.UserSummary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserSummaryApplicationTests {

	@Test
	void contextLoads() {
	}

}
