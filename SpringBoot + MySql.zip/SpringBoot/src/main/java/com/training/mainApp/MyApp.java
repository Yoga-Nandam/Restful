package com.training.mainApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan({"com.training.controller","com.training.dao"})
public class MyApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(MyApp.class,args);
	}

}
