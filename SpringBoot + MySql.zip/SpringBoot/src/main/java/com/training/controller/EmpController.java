package com.training.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.training.model.LoginBean;
import com.training.model.RegistrationBean;
import com.training.dao.EmpDAO;

@RestController
public class EmpController {
	@Autowired
	public EmpDAO empDAO;
	
	@RequestMapping("/")
	public String msg()
	{
		return "Hello Yoga!!";
	}
	
	@RequestMapping("/welcome")
	public ModelAndView welcome(Model m)
	{
		m.addAttribute("message", "Welcome to spring Boot app");
		return new ModelAndView("HomePage");
	}
	
	@RequestMapping("/login")
	public ModelAndView login(Model m,@ModelAttribute("LoginBean")LoginBean loginBean)
	{
		String requestMapping = "login";
		if(loginBean.getUserName() != null && loginBean.getPassword() !=null) {
			String name = empDAO.loginValidate(loginBean.getUserName(), loginBean.getPassword());
			if(name != null)
			{
				m.addAttribute("UserName", name);	
				requestMapping = "success";
			}
			else
			{
				m.addAttribute("error", "You've entered invalid User name and Password");
				requestMapping = "failure";
			}
			
		}
		
		return new ModelAndView(requestMapping);
	}
	
	@RequestMapping("/registrationPage")
	public ModelAndView Registration(Model m,@ModelAttribute("RegistrationBean")RegistrationBean registrationBean)
	{
		String requestMapping = "Registration";
		if(registrationBean.getFirstName() !=null) {
			int  name = empDAO.registrationEmp(registrationBean);
			if(name != 0)
			{
				m.addAttribute("UserName", "You've register successfully!!!");	
				requestMapping = "success";
			}
			else
			{
				m.addAttribute("error", "You've entered invalid User name and Password");
				requestMapping = "failure";
			}
		}
		//m.addAttribute("message", "Welcome to spring Boot app");
		return new ModelAndView(requestMapping);
	}
	
	
}
