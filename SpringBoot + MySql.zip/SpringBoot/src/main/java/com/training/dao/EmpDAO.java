package com.training.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.training.model.RegistrationBean;

@Component
public class EmpDAO {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public String loginValidate(String userName, String pwd) {
		String str = null;
		PreparedStatement pstmt = null;
		try {
			String SQL = "select fname from register where fname=? and password =?";
			pstmt = jdbcTemplate.getDataSource().getConnection().prepareStatement((SQL));
			pstmt.setString(1, userName);
			pstmt.setString(2, pwd);
			ResultSet resultSet = pstmt.executeQuery();

			if (resultSet.next()) {
				str = resultSet.getString("fname").toString();
			}
		} catch (SQLException e) {
			System.out.println(e);
		}
		return str;
	}
	
	
	public int registrationEmp(RegistrationBean bean) {
		//String str = null;
		PreparedStatement pstmt = null;
		int resultSet =0;
		try {
			String SQL = "insert into register value(?,?,?,?,?,?,?,?,?)";
			pstmt = jdbcTemplate.getDataSource().getConnection().prepareStatement((SQL));
			pstmt.setString(1, bean.getFirstName());
			pstmt.setString(2, bean.getLastName());
			pstmt.setString(3, bean.getPassword());
			pstmt.setString(4, bean.getConfirmPassword());
			pstmt.setString(5, bean.getEmail());
			pstmt.setString(6, bean.getGender());
			pstmt.setString(7, bean.getCountry());
			pstmt.setString(8, bean.getState());
			pstmt.setString(9, bean.getPhone());
			
			resultSet =  pstmt.executeUpdate();

			/*if (resultSet.next()) {
				str = resultSet.getString("fname").toString();
			}*/
		} catch (SQLException e) {
			System.out.println(e);
		}
		return resultSet;
	}

}
