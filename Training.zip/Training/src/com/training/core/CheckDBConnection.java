package com.training.core;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class CheckDBConnection {
	
	public static void main(String args[])
	{
		System.out.println("-------- Oracle JDBC Connection Testing ------");

        try {

          //  Class.forName("oracle.jdbc.driver.OracleDriver");
            Class.forName("com.mysql.jdbc.Driver");
            

        } catch (ClassNotFoundException e) {

            System.out.println("Where is your Oracle JDBC Driver?");
            e.printStackTrace();
            return;

        }

        System.out.println("Oracle JDBC Driver Registered!");

        Connection connection = null;

        try {
        	System.out.println("Initiating connection");
          /*  connection = DriverManager.getConnection(
                    "jdbc:oracle:thin:@127.0.0.1:8080:xe", "system", "scott");*/
            
            connection = DriverManager.getConnection(
            		 "jdbc:mysql://localhost:3306/yoga","root","scott");
            
            

        } catch (SQLException e) {

            System.out.println("Connection Failed! Check output console");
            e.printStackTrace();
            return;

        }

        if (connection != null) {
            System.out.println("You made it, take control your database now!");
        } else {
            System.out.println("Failed to make connection!");
        }
    }

	}



