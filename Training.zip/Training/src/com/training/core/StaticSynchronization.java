package com.training.core;


class synchronization
{
	synchronized static void print(int n) 
	{
		for(int i=0; i<n;i++)
		{
			System.out.println(n*i);
			try {
				Thread.sleep(30);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}

class Thread1 extends Thread
{
	public void run()
	{
		synchronization.print(1);
	}
}

class Thread2 extends Thread
{
	public void run()
	{
		synchronization.print(10);
	}
}

class Thread3 extends Thread
{
	public void run()
	{
		synchronization.print(100);
	}
}

class Thread4 extends Thread
{
	public void run()
	{
		synchronization.print(1000);
	}
}

public class StaticSynchronization {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Thread1 t1 = new Thread1();
		Thread2 t2 = new Thread2();
		Thread3 t3 = new Thread3();
		Thread4 t4 = new Thread4();
		
		t1.start();
		t2.start();
		t3.start();
		t4.start();

	}

}
