package com.training.core;

public class IdentityHashMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//IdentityHashMap
		
		/*map.put(101,"yoga");
		map.*/
		
		

	}

}
