package com.training.core;

import java.io.IOException;

public class TestException {
	 public String toString()
	{
		System.out.println("message");
		return null;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(new TestException().toString());
		
		try
		{
			throw new IOException("Hello");
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		/*catch(IOException e)
		{
			System.out.println(e.getMessage());
		}*/

	}

}
