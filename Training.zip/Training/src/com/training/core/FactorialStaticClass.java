package com.training.core;

public class FactorialStaticClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int value = fact(5);
		System.out.println(value);

	}
	static int fact(int num)
	{
		int output;
		if(num==1)
		{
			return 1;
		}
		output = fact(num-1) *num;
		return output;
	}

}
