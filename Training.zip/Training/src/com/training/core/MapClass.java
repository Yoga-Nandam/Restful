package com.training.core;

import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Map;

public class MapClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Map map = new HashMap();
		
		//IdentityHashMap map = new IdentityHashMap<>();
		
		//Hashtable map = new Hashtable(); Null pointer exception throws at RE if null key or value exists in collection objec
		
		map.put(101, "yoga");
	//	map.put(102, "bala");
	//	map.put(101, "rami");
		map.put(null, "vetha");
		map.put(null, "muniraj");
		map.put(104, null);
		map.put(105, null);
		
		System.out.println(map);

	}

}
