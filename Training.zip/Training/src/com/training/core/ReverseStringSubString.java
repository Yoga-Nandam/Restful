package com.training.core;

public class ReverseStringSubString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str= "yoganandam";
		System.out.println("Reverse :"+reverse(str));
		
	}
	public static String reverse(String str)
	{
		if(str.isEmpty())
		{
			return str;
		}
		return reverse(str.substring(1)) + str.charAt(0);
				
	}

}
