package com.training.core;

import java.util.Arrays;

public class SecondLargestValue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]={1,2,7,6,3,2};  
		int b[]={44,88,99,77,33,22,55};  
		
		System.out.println("Iteration way :" +secondLargest(a,6));
		System.out.println("ArraySort() way :" +secondLargestArraySort(b,7));

	}
	static int secondLargest(int a[],int total)
	{
		int temp;
		
		for(int i=0;i<total;i++)
		{
			for(int j=i+1;j<total;j++)
			{
				if(a[i]>a[j])
				{
					temp = a[i];
					a[i] = a[j];
					a[j] =temp;
				}
			}
			
		}
		return a[total-2];
	}
	
	static int secondLargestArraySort(int a[],int total) {
		
		
		Arrays.sort(a);
		return a[total-2];
	}

}
