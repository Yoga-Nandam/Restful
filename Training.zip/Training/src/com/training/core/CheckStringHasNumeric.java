package com.training.core;

public class CheckStringHasNumeric {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str = "bala5Yoga";
		
		for(int i=0;i<str.length();i++)
		{
			char arr = str.charAt(i);
			if((arr >='a' && arr <= 'z') ||  (arr >='A' && arr <='Z'))
			{
				System.out.println(arr);
			}
			else
			{
				System.out.println("non-alphabetic :"+arr);
			}
		}

	}

}
