package com.training.core;

public class SwapNoTemp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a=10, b=5;
		System.out.println("Before swap :");
		System.out.println("A ="+a+ " "+"B ="+b);
		
		a= a+b;
		b= a-b;
		a= a-b;
		
		System.out.println("After swap :");
		System.out.println("A ="+a+ " "+"B ="+b);

	}

}
