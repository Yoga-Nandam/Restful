package com.training.core;

public class PrimeStaticClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 2;
	//	boolean bool = prime(num);
		
		if(!prime(num))
		{
			System.out.println(true);
		}
		else
		{
			System.out.println(false);
		}

	}
	public static boolean prime(int num)
	{
		boolean flag = false;
		for(int i=2; i<=num/2; i++)
		{
			if(num % i == 0)
			{
				flag = true;
				break;
			}
		}
		return flag;
	}

}
