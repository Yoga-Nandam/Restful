package com.training.core;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class FindDuplicateLStringHashMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//String str = "Welcome to our hoome";
		
		int a[] = {1,3,4,3,5,6,4};
		
		String str = Arrays.toString(a);
		
		Map<Character,Integer> mm = new HashMap<>();
		
		for(char c : str.toCharArray())
		{
			if(c!=',' && mm.containsKey(c))
			{
				mm.put(c, mm.get(c)+1);
			}
			else
				mm.put(c, 1);
		}
		for(Map.Entry<Character, Integer> hm : mm.entrySet())
		{
			if(hm.getValue() >1 )
			{
				System.out.println(hm.getKey()/*+ " "+hm.getValue()*/);
			}
		}

	}

}
