package com.training.core;

import java.util.Set;
import java.util.TreeSet;

public class TreesetClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str = "Yoga";
		
		Set set = new TreeSet();
		
	//	set.add("Bala");
		set.add(new StringBuffer("yoga"));
		set.add(new StringBuilder("yoga"));
	//	set.add(5);set.add(15);set.add(25);set.add(35);
		
		for(Object obj : set)
		{
			System.out.println(obj);
		}
		
	

	}

}
