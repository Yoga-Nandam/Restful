package com.training.core;

public class ArmStrongNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	int a = 153;
		int r,temp,c=0;
		temp = a;
		
		while(a!=0)
		{
			r = a%10;
			a = a / 10;
			c = c + (r*r*r);
		}
		if(temp == c)
		{
			System.out.println("Equal :"+c);
		}
		
		armStrong(a);

	}
	
	static void armStrong(int num)
	{
		int r,c=0;
		int temp = num;
		while(num!=0)
		{
			r = num % 10;
			c = c+(r*r*r);
			armStrong(num/10);
		}
		if(temp == c)
		{
			System.out.println("Recursion Equals :"+c);
		}
		else
		{
			System.out.println("Not equals");
		}
	}

}
