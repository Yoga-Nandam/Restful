package com.training.core;

public class BinarySearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int arr[] = {5,6,7,9,8,3,1,4,2,10};
		
		System.out.println("welcome");
		
		System.out.println("key value 10 position is:"+binary(arr,10));
		
		System.out.println("Using Recursive key value 10 position is:"+binaryRecursive(arr,10,0,arr.length));

	}
	
	static int binary(int arr[], int key)
	{
		int start =0;
		int end = arr.length;
		
		
		while(start <= end)
		{
			int mid = (start+end)/2;
			if(key == arr[mid])
			{
				return mid;
			}
			if(key < arr[mid])
			{
				end = mid-1;
			}
			else {
				start = mid + 1;				
			}
				
		}
		
		return -1;
	}
	
	static int binaryRecursive(int arr[],int key,int start, int end) {
		
		if(start<end)
		{
			int mid = (start+end) /2;
			
			if(key == mid)
			{
				return mid;
			}
			if(key < arr[mid])
			{
				return binaryRecursive(arr,key,start,mid-1);
			}
			else
				return binaryRecursive(arr,key,mid+1,end);
		}
		
		
		return -1;
	}

}
