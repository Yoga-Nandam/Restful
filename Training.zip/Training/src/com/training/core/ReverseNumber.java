package com.training.core;

public class ReverseNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num = 153;
		int r = 0;
		
		while(num!=0)
		{
			r = num % 10;
			num = num/10;
			System.out.print(r);
		}

	}

}
