package com.training.core;

interface A{
	void show();
	interface B
	{
		void msg();
	}
}

 class NestedInterface implements A.B{
	 
	 public void show() {
		 	System.out.println("outerInterface");
	 }
	 
	 public void msg()
	 {
		 System.out.println("Inner Interface");
	 }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		A.B ab = new NestedInterface();
		ab.msg();
		NestedInterface ni = new NestedInterface();
		ni.show();

	}

}
