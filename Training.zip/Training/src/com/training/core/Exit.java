package com.training.core;

class Mythread extends Thread
{
	public void run()
	{
		System.out.println("before close");
	}
}

public class Exit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Mythread thread = new Mythread();
		Runtime rm = Runtime.getRuntime();
		rm.addShutdownHook(thread);
		System.out.println("JVM gonna shutdown");
		System.exit(0);
		
		/*try {
			System.out.println("inside block");
			System.exit(1);
			System.out.println("block-inside");
		}
		catch(Exception e)
		{
			System.out.println("catch block");
		}
		finally {
			System.out.println("Finally Block");
		}
		System.out.println("Outside try-catch block");

*/	}

}
