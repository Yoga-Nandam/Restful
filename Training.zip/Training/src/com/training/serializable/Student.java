package com.training.serializable;

import java.io.Serializable;

public class Student implements Serializable{
	
//	public static Student student = new Student(id, college, college, d);
	int id;
	String name;
	static String college = "PEC";
	transient double d = 3.14;
	
	final int phone = 6892980;
	Student(int id,String name,String college,double d)
	{
		this.id = id;
		this.name = name;
		this.college = college;
		this.d = d;
		//this.phone = phone;
	}
	
	/*public Object readResolve()
	{
		if(student==null)
		{
			student = new Student(id, name, name, d);
		}
		return student;
		
	}*/

}
