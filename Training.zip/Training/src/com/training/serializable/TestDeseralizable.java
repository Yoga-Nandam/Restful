package com.training.serializable;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class TestDeseralizable {

	public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		
		ObjectInputStream oin = new ObjectInputStream(new FileInputStream("C:\\Users\\Yoga\\Desktop\\serizable.txt"));
		
		Student stu = (Student)oin.readObject();
		
		System.out.println(stu.id + " "+stu.name);
		System.out.println("Static variable"+stu.college);
		System.out.println("Transient :"+stu.d);
		System.out.println(stu.hashCode());

	}

}
