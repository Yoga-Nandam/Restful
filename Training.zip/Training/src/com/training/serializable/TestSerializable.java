package com.training.serializable;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class TestSerializable {

	public static void main(String[] args) throws FileNotFoundException, IOException {
		// TODO Auto-generated method stub
		
		Student stu = new Student(18,"Yoga","PEO",6.14);
		
		ObjectOutputStream obj = new ObjectOutputStream(new FileOutputStream("C:\\Users\\Yoga\\Desktop\\serizable.txt"));
		
		obj.writeObject(stu);
		obj.flush();
		
		System.out.println("Success");
		System.out.println(stu.hashCode());

	}

}
